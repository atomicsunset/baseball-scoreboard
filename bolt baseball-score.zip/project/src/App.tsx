import React, { useState, useEffect } from 'react';
import { MinusCircle, PlusCircle, RotateCcw, Copy } from 'lucide-react';

interface Team {
  name: string;
  runs: number;
  hits: number;
  errors: number;
}

interface GameState {
  homeTeam: Team;
  awayTeam: Team;
  inning: number;
  isTopInning: boolean;
}

const initialState: GameState = {
  homeTeam: { name: 'Home', runs: 0, hits: 0, errors: 0 },
  awayTeam: { name: 'Away', runs: 0, hits: 0, errors: 0 },
  inning: 1,
  isTopInning: true,
};

function App() {
  const [gameState, setGameState] = useState<GameState>(initialState);
  const [copied, setCopied] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const connectWebSocket = () => {
      const socket = new WebSocket('ws://localhost:8080');
      
      socket.onopen = () => {
        console.log('Connected to WebSocket server');
        setConnected(true);
        setWs(socket);
        // Send initial state
        socket.send(getVmixData());
      };

      socket.onclose = () => {
        console.log('Disconnected from WebSocket server');
        setConnected(false);
        setWs(null);
        // Try to reconnect after 2 seconds
        setTimeout(connectWebSocket, 2000);
      };

      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnected(false);
        setWs(null);
      };
    };

    connectWebSocket();

    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, []);

  // Send updates to WebSocket server when state changes
  useEffect(() => {
    if (ws && connected) {
      ws.send(getVmixData());
    }
  }, [gameState, ws, connected]);

  // Generate JSON data for vMix
  const getVmixData = () => {
    return JSON.stringify([{
      homeTeam: gameState.homeTeam.name,
      homeRuns: gameState.homeTeam.runs,
      homeHits: gameState.homeTeam.hits,
      homeErrors: gameState.homeTeam.errors,
      awayTeam: gameState.awayTeam.name,
      awayRuns: gameState.awayTeam.runs,
      awayHits: gameState.awayTeam.hits,
      awayErrors: gameState.awayTeam.errors,
      inning: gameState.inning,
      inningHalf: gameState.isTopInning ? 'Top' : 'Bottom'
    }], null, 2);
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(getVmixData());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const updateTeamStat = (
    team: 'homeTeam' | 'awayTeam',
    stat: 'runs' | 'hits' | 'errors',
    delta: number
  ) => {
    setGameState((prev) => ({
      ...prev,
      [team]: {
        ...prev[team],
        [stat]: Math.max(0, prev[team][stat] + delta),
      },
    }));
  };

  const toggleInningHalf = () => {
    setGameState((prev) => ({
      ...prev,
      isTopInning: !prev.isTopInning,
      inning: !prev.isTopInning ? prev.inning + 1 : prev.inning,
    }));
  };

  const resetGame = () => {
    if (confirm('Are you sure you want to reset the game?')) {
      setGameState(initialState);
    }
  };

  const StatControl = ({ 
    value, 
    onIncrement, 
    onDecrement 
  }: { 
    value: number; 
    onIncrement: () => void; 
    onDecrement: () => void;
  }) => (
    <div className="flex items-center gap-2">
      <button
        onClick={onDecrement}
        className="p-1 text-gray-600 hover:text-red-600 transition-colors"
        aria-label="Decrease"
      >
        <MinusCircle className="w-5 h-5" />
      </button>
      <span className="w-8 text-center font-mono text-xl">{value}</span>
      <button
        onClick={onIncrement}
        className="p-1 text-gray-600 hover:text-green-600 transition-colors"
        aria-label="Increase"
      >
        <PlusCircle className="w-5 h-5" />
      </button>
    </div>
  );

  const TeamRow = ({ team, type }: { team: Team; type: 'homeTeam' | 'awayTeam' }) => (
    <div className="flex items-center gap-6 p-4 bg-white rounded-lg shadow-sm">
      <input
        type="text"
        value={team.name}
        onChange={(e) => setGameState(prev => ({
          ...prev,
          [type]: { ...prev[type], name: e.target.value }
        }))}
        className="w-32 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      <div className="flex gap-8">
        <div className="flex flex-col items-center">
          <span className="text-sm font-semibold text-gray-500">RUNS</span>
          <StatControl
            value={team.runs}
            onIncrement={() => updateTeamStat(type, 'runs', 1)}
            onDecrement={() => updateTeamStat(type, 'runs', -1)}
          />
        </div>
        <div className="flex flex-col items-center">
          <span className="text-sm font-semibold text-gray-500">HITS</span>
          <StatControl
            value={team.hits}
            onIncrement={() => updateTeamStat(type, 'hits', 1)}
            onDecrement={() => updateTeamStat(type, 'hits', -1)}
          />
        </div>
        <div className="flex flex-col items-center">
          <span className="text-sm font-semibold text-gray-500">ERRORS</span>
          <StatControl
            value={team.errors}
            onIncrement={() => updateTeamStat(type, 'errors', 1)}
            onDecrement={() => updateTeamStat(type, 'errors', -1)}
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-800">Baseball Scoreboard</h1>
          <div className="flex items-center gap-4">
            <div className={`h-3 w-3 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
            <span className="text-sm text-gray-600">
              {connected ? 'Connected' : 'Disconnected'}
            </span>
            <button
              onClick={resetGame}
              className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg shadow-sm hover:bg-gray-50 text-gray-600"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <TeamRow team={gameState.awayTeam} type="awayTeam" />
          <TeamRow team={gameState.homeTeam} type="homeTeam" />
        </div>

        <div className="flex justify-center items-center gap-6 p-4 bg-white rounded-lg shadow-sm">
          <div className="flex flex-col items-center">
            <span className="text-sm font-semibold text-gray-500">INNING</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setGameState(prev => ({
                  ...prev,
                  inning: Math.max(1, prev.inning - 1)
                }))}
                className="p-1 text-gray-600 hover:text-red-600 transition-colors"
                aria-label="Previous inning"
              >
                <MinusCircle className="w-5 h-5" />
              </button>
              <span className="w-8 text-center font-mono text-xl">{gameState.inning}</span>
              <button
                onClick={() => setGameState(prev => ({
                  ...prev,
                  inning: prev.inning + 1
                }))}
                className="p-1 text-gray-600 hover:text-green-600 transition-colors"
                aria-label="Next inning"
              >
                <PlusCircle className="w-5 h-5" />
              </button>
            </div>
          </div>

          <button
            onClick={toggleInningHalf}
            className={`px-4 py-2 rounded-lg font-semibold ${
              gameState.isTopInning
                ? 'bg-blue-100 text-blue-700'
                : 'bg-orange-100 text-orange-700'
            }`}
          >
            {gameState.isTopInning ? 'Top' : 'Bottom'}
          </button>
        </div>

        <div className="mt-8 p-4 bg-white rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800">vMix Data Source</h2>
            <button
              onClick={copyToClipboard}
              className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-600 rounded hover:bg-blue-100"
            >
              <Copy className="w-4 h-4" />
              {copied ? 'Copied!' : 'Copy JSON'}
            </button>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            To use this scoreboard with vMix:
          </p>
          <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600 mb-4">
            <li>The scoreboard automatically updates vmix-data.json in the same folder as this app</li>
            <li>In vMix, add a new "Data Source" input</li>
            <li>Select "JSON" as the data type</li>
            <li>Choose vmix-data.json as your data source</li>
            <li>Use these field names in your graphics:
              <ul className="list-disc list-inside ml-4 mt-2 text-xs font-mono">
                <li>homeTeam, homeRuns, homeHits, homeErrors</li>
                <li>awayTeam, awayRuns, awayHits, awayErrors</li>
                <li>inning, inningHalf</li>
              </ul>
            </li>
          </ol>
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <pre className="text-xs overflow-auto">{getVmixData()}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;