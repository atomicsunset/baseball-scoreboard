import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { writeFile } from 'fs/promises';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const server = createServer();
const wss = new WebSocketServer({ server });
const JSON_FILE_PATH = join(__dirname, '..', 'vmix-data.json');

wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('message', async (data) => {
    try {
      // Write the updated data to the JSON file
      await writeFile(JSON_FILE_PATH, data.toString(), 'utf8');
      console.log('Updated vMix data file');
    } catch (error) {
      console.error('Error writing to file:', error);
    }
  });

  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

server.listen(8080, () => {
  console.log('WebSocket server running on port 8080');
});