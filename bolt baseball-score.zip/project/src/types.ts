export interface Team {
  name: string;
  runs: number;
  hits: number;
  errors: number;
}

export interface GameState {
  homeTeam: Team;
  awayTeam: Team;
  inning: number;
  isTopInning: boolean;
}