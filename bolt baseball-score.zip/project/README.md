# Baseball Scoreboard for vMix

A real-time baseball scoreboard that automatically updates a JSON file for use with vMix's data sources.

## Important Note
The web preview at https://effervescent-llama-2f436b.netlify.app is just a demo. To use this with vMix, you need to run the application locally on your computer.

## Quick Start Guide

1. Download the project:
   ```bash
   git clone https://github.com/atomicsunset/baseball-scoreboard.git
   # or download and extract the ZIP file from the releases page when available
   ```

2. Install Node.js:
   - Download from: https://nodejs.org/
   - Required version: 18 or later

3. Set up the project:
   ```bash
   cd baseball-scoreboard
   npm install
   npm run dev
   ```

4. Access the scoreboard:
   - Open http://localhost:5173 in your browser
   - The `vmix-data.json` file will be created automatically in the project folder

## Using with vMix

1. After starting the application, locate the `vmix-data.json` file in the project folder
2. In vMix:
   - Add a new "Data Source" input
   - Select "JSON" as the data type
   - Choose the `vmix-data.json` file from your project folder
3. Available fields for your graphics:
   - `homeTeam`, `homeRuns`, `homeHits`, `homeErrors`
   - `awayTeam`, `awayRuns`, `awayHits`, `awayErrors`
   - `inning`, `inningHalf`

## Connection Status

The scoreboard shows a connection indicator in the top-right corner:
- 🟢 Green: Connected and updating vMix data
- 🔴 Red: Disconnected (will automatically try to reconnect)

## Features

- Real-time score updates
- Team name customization
- Inning tracking with top/bottom indicator
- Runs, hits, and errors tracking for both teams
- Automatic vMix data file updates
- WebSocket connection status indicator
- Copy JSON data functionality
- Game reset option

## Development

This project uses:
- React with TypeScript
- Tailwind CSS for styling
- WebSocket for real-time updates
- Vite for development and building

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct and the process for submitting pull requests.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.